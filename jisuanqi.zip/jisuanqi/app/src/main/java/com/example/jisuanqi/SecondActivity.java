package com.example.jisuanqi;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class SecondActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_second);
        EditText shuru = (EditText) findViewById(R.id.shuru);
        TextView shuchu = (TextView) findViewById(R.id.shuchu);
        Button changdu = (Button) findViewById(R.id.changdu);
        Button tiji = (Button) findViewById(R.id.tiji);
        Button erjinzhi = (Button) findViewById(R.id.erjinzhi);
        Button bajinzhi = (Button) findViewById(R.id.bajinzhi);
        Button shijinzhi = (Button) findViewById(R.id.shijinzhi);
        Button shiliujinzhi = (Button) findViewById(R.id.shiliujinzhi);
        Button sin = (Button) findViewById(R.id.sin);
        Button cos = (Button) findViewById(R.id.cos);
        Button tan = (Button) findViewById(R.id.tan);
        Button kaigenhao = (Button) findViewById(R.id.kaigenhao);
        Button qingkong = (Button) findViewById(R.id.qingkong);
        qingkong.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                EditText shuru = (EditText) findViewById(R.id.shuru);
                shuru.setText("");
            }
        });
        changdu.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                EditText shuru = (EditText) findViewById(R.id.shuru);
                TextView shuchu = (TextView) findViewById(R.id.shuchu);
                double[] m = {0};
                m[0] = Double.parseDouble(shuru.getText().toString() + "");
                shuchu.setText(m[0] + " 米 = " + (m[0] / 1000) + " 公里 = " + (m[0] * 100) + " 厘米 = " + (int) (m[0] * 1000000) + " 毫米");
            }
        });
        tiji.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                EditText shuru = (EditText) findViewById(R.id.shuru);
                TextView shuchu = (TextView) findViewById(R.id.shuchu);
                double[] m = {0};
                m[0] = Double.parseDouble(shuru.getText().toString() + "");
                shuchu.setText(m[0] + " 立方米 = " + (m[0] * 1000) + " 立方分米 = " + (int) (m[0] * 1000000) + " 立方厘米");
            }
        });
        erjinzhi.setOnClickListener(new View.OnClickListener() {  //进制转化的方法我是选择将二进制8进制 十进制 十六进制等都先转化为二进制在进行计算其他进制
            @Override
            public void onClick(View v) {
                EditText shuru = (EditText) findViewById(R.id.shuru);
                TextView shuchu = (TextView) findViewById(R.id.shuchu);
                String m = shuru.getText().toString() + "";
                int n = 0;
                if (m.indexOf('.') != -1) { 
                    n = m.indexOf('.');   //n是小数点的位置  接下来想小数点两边添加0
                    //接下来是二进制转八进制
                    if ((m.length() - n) % 3 == 0) {         //小数点后面的小数部分  在末尾补零构成3位的整数倍
                        m = m + "0";
                    }
                    if ((m.length() - n) % 3 == 2) {
                        m = m + "00";
                    }
                    if (n % 3 == 1) {    //小数点前面的整数部分在第一位补零构成3位的整数倍
                        m = "00" + m;
                    }
                    if (n % 3 == 2) {
                        m = "0" + m;
                    }   //至此补零结束  开始计算八进制
                }
                else {  //如果没有小数点
                    if (m.length() % 3 == 1) {
                        m = "00" + m;
                    }
                    if (m.length() % 3 == 2) {
                        m = "0" + m;
                    }
                }
                String O = "0";      //O用来记录一下计算结果
                for (int i = 0; i < (m.length()/3)+1; i++) {
                    if(n==3*i) {   //如果找到了小数点  就放入小数点
                        O = O + ".";
                        m.replace(".","");
                    }
//                       O = O +(((int)m.charAt(3*i)-48)*4+((int)m.charAt(3*i+1)-48)*2+((int)m.charAt(3*i+8)-48));
                }
                shuchu.setText(m);
            }


        });
    }

        public void startMainActivity (View view){
            Intent intent = new Intent();
            intent.setClass(this, MainActivity.class);
            //启动
            startActivity(intent);
        }
}